package com.example.imc_aplicativo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class home extends AppCompatActivity {

    private EditText edtPeso, edtAltura;
    private Button btnCalcular;
    private TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        edtPeso = findViewById(R.id.editTextText3);
        edtAltura = findViewById(R.id.editTextText4);
        btnCalcular = findViewById(R.id.button6);
        txtResultado = findViewById(R.id.editTextText5);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularIMC();
            }
        });
    }

    private void calcularIMC() {
        String pesoStr = edtPeso.getText().toString();
        String alturaStr = edtAltura.getText().toString();

        if (!pesoStr.isEmpty() && !alturaStr.isEmpty()) {
            double peso = Double.parseDouble(pesoStr);
            double altura = Double.parseDouble(alturaStr);
            double imc = peso / (altura * altura);

            String resultado = "Seu IMC: " + String.format("%.2f", imc);
            txtResultado.setText(resultado);
        } else {
            txtResultado.setText("Preencha todos os campos!");
        }
    }
}
